package com.pack.controller;

import java.util.HashMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Customer;
import com.pack.model.LoginUser;
import com.pack.util.Util;
@Controller
public class UserController {
	@RequestMapping("login")
	public String login(Model m)
	{
		
		m.addAttribute("userBean", new LoginUser());
		return "login";
	}
	@RequestMapping(value="validate", method = RequestMethod.POST)
	public String submitForm(@Valid @ModelAttribute("userBean")LoginUser u,BindingResult result,Model m)
	{
		 if (result.hasErrors())
			 {
	
			  return "login";
			 }
	 else
	 {
  		  
	  return "homepage";
		
		
	}
	}
	@Autowired
	private Customer customer;
	HashMap hm=new HashMap();
	@RequestMapping("/UtilController")
	public String getToppings(Model m)
	{
		System.out.println("into util controller");
		hm=Util.getToppings();
		System.out.println("hm "+hm);
		m.addAttribute("pizzaToppings",hm);
		m.addAttribute("customer",new Customer());
		return "placeorder";
	}
}
