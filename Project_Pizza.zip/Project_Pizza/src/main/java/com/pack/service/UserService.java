package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;
import com.pack.model.Pizzaorder;

import com.pack.dao.UserDao;
import com.pack.model.LoginUser;
public class UserService {
	@Autowired
	private UserDao userDAO;
 public void login(LoginUser user) {
				  userDAO.validate(user);  
				
			}
 public void homepage(Pizzaorder order) {
	 userDAO.placeOrder(order);
 }
			  
}
