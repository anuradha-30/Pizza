package com.pack.util;

import java.util.HashMap;

public class Util {
	private static HashMap<Integer,String> toppings=new HashMap();
	public static HashMap<Integer,String> getToppings() {
		return toppings;
}
}
